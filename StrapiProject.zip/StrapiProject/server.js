const Koa = require("koa");
const { ApolloServer } = require("apollo-server-koa");


const typeDefs = require('./schema')

const resolvers = require('./resolvers')

const server = new ApolloServer({ typeDefs, resolvers });

const app = new Koa();

;(async () => {
    try {
      await server.start()
      server.applyMiddleware({ app, path: "/graphql" });
          
    } catch (err) {
      console.log(err)
     
    }
  })()



const port = 3000;

app.listen(port, () => console.log(`listening at port ${port}`));
