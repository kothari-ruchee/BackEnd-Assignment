const { gql } = require('apollo-server-koa');

const typeDefs = gql`

scalar DateTime

type Planet {
    id: ID!
    name: String
    code: String
    spaceCenters(limit: Int): [SpaceCenter]
}

type Page {
    total: Int
    page: Int
    pageSize: Int
  }

type SpaceCenter{
    id: ID!
    uid: String!
    name: String
    description: String
    latitude: Float
    longitude: Float
    planet: Planet
    planet_code:Int
  }

  
  type Flight{
      id: ID!
      code:String
      launchSite:SpaceCenter
      landingSite:SpaceCenter
      departureAt:DateTime
      seatCount: Int
      availableSeats: Int
  }

  type Booking{
      id:ID!
      flight:Flight
      seatCount: Int
      email: String
  }

  type spaceCenters{
    pagination: Page
    nodes: [SpaceCenter]
  }

  type bookings{
      pagination: Page
      nodes: [Booking]
  }
 
  type flights{
    pagination: Page
    nodes: [Flight]
  }

 
  type Query {
    planets: [Planet]
    spaceCenters(page:Int, pageSize:Int):spaceCenters
    spaceCenter(id:ID, uid:String): SpaceCenter
    flights(page:Int, pageSize:Int):flights
    flight(id:ID!): Flight
    bookings(email:String!, page:Int, pageSize:Int):bookings
    booking(id:ID!): Booking

  }

  input BookingFlightInput {
    seatCount:Int!
    flightId:Int!
    email:String!
  }

  input ScheduleFlightInput{
    launchSiteId:ID!,
    landingSiteId:ID!,
    departureAt:DateTime!,
    seatCount:Int!
  }

  type Mutation{
    scheduleFlight(flightInfo:ScheduleFlightInput!):[Flight]
    bookFlight(bookingInfo: BookingFlightInput!):[Booking]
  }

`;

module.exports = typeDefs;