const data=require('./data')
const DateTime=require('./DateTime')

module.exports = {
  DateTime:DateTime,
    Query: {
     planets: () => data.getAllPlanets(),
    spaceCenters: (_,args) => data.getPageDetails(args),
    spaceCenter:(_,args) => data.getSpaceCenterByID(args.id,args.uid),
    flights:(_,args) => data.getPageDetails(args),
    flight:(_,args) => data.getFlightByID(args.id),
    bookings:(_,args) => data.getPageDetails(args),
    booking:(_,args)=> data.getBookingByID(args.id)
    },
    Planet: {
      spaceCenters(parent,args) {
          return data.getSpaceCentersByPlanetCode(parent,args)
      
      }
    },
    spaceCenters:{
      pagination(parent){
        return data.getPageInfo("space_centers",parent.page,parent.pageSize)
        },
        nodes(parent){
          return data.getListOfSpaceCenters(parent.page,parent.pageSize)
        }
    },
    SpaceCenter:{
       planet(parent){
       return data.getPlanetByID(parent.planet_code)
      }
    },
    Flight:{
      launchSite(parent){
        return data.getSpaceCenterByID(parent.launching_site,null)
      },
      landingSite(parent){
        return data.getSpaceCenterByID(parent.landing_site,null)
      },
      availableSeats(parent){
        return data.getAvailableSeatCount(parent)
      },
      seatCount(parent){
        return parent.seat_count
      }
        
    },
    flights:{
      pagination(parent){
        return data.getPageInfo("flights",parent.page,parent.pageSize)
        },
        nodes(parent){
          return data.getListOfFlights(parent.page,parent.pageSize)
        }
    },
     bookings:{
      pagination(parent){
        return data.getPageInfo("bookings",parent.page,parent.pageSize)
        },
        nodes(parent){
          return data.getBookings(parent.page,parent.pageSize,parent.email)
        }
    },
    Booking:{
      seatCount: (parent) => parent.seat_count,
       flight:(parent)=>  data.getFlightByID(parent.flight_id)
    },
    Mutation: {
      scheduleFlight: (_,args) =>  data.scheduleFlight(args.flightInfo),
      bookFlight:(_,args) =>  data.bookFlight(args.bookingInfo)
    },
      

    
    }
  
  


  