const knex=require('../db')
const spaceCentersData = require('../data/space-centers')
const planetsData=require('../data/planets')
const flightsData=require('../data/flights')
const bookingsData=require('../data/bookings')




;(async () => {
  try {
      // Delete ALL existing entries
    await  knex('bookings').del().then(() => {
    return knex('flights').del();
  })
  .then(() => {
    return knex('space_centers').del();
  })
  .then(() => {
    return knex('planets').del();
  })
   // Insert planets 
   .then(function () {
     return knex('planets').insert(planetsData);
  })
  // Insert space_centers
  .then(function () {
      let spaceCenterPromises = [];
      spaceCentersData.forEach((spaceCenter) => {
      spaceCenterPromises.push(createSpaceCenterRecord(knex, spaceCenter));
    })
    return Promise.all(spaceCenterPromises);
   })

  // Uncomment the following lines if you want to add dummy flight and bookings record

  //  // Insert Flights
  //  .then(function () {
  //   let flightPromises=[];
  //   flightsData.forEach((flight)=>{
  //      flightPromises.push(createFlightRecord(knex,flight))
  //   })

  //   return Promise.all(flightPromises);
   
  // })
  //   // Insert Bookings
  //   .then(function () {
  //     let bookingsPromises = [];
  //     bookingsData.forEach((booking) => {
  //      bookingsPromises.push(createBookingRecord(knex, booking));
  //   })
  //   return Promise.all(bookingsPromises);
  //  })

   console.log('Inserted Data into tables!')
   process.exit(0)
 } catch (err) {
   console.log(err)
   process.exit(1)
 }
})()

async function getSite(knex,site) {
    return knex('space_centers').select('id').where('uid', site).first()
}

const createSpaceCenterRecord = (knex, spaceCenter) => {
  return knex('planets').select('id').where('code', spaceCenter.planet_code).first()
  .then((planetRecord) => {
    return knex('space_centers').insert({
      uid:spaceCenter.uid,
      name: spaceCenter.name,
      description:spaceCenter.description,
      latitude:spaceCenter.latitude,
      longitude:spaceCenter.longitude,      
      planet_code: planetRecord.id
    })
  })
}

const createFlightRecord= async (knex,flight) => {
  const launchingSite= await getSite(knex,flight.launching_site)
  const landingSite= await  await getSite(knex,flight.landing_site)
   return knex('flights').insert({
    code: flight.code,
    departure_at:flight.departure_at,
    launching_site: launchingSite.id,
    landing_site: landingSite.id,
    seat_count:flight.seat_count
  })
  
}

const createBookingRecord = (knex, booking) => {
  return knex('flights').select('id').where('code', booking.flight).first()
  .then((flightRecord) => {
    return knex('bookings').insert({
      seat_count:booking.seat_count,
      email:booking.email,
      flight_id:flightRecord.id
    })
  })
}



