const knex = require('knex')

module.exports = knex({
  client: 'postgres',
  connection: {
    host: 'db',
    user: 'strapi',
    password: 'password',
    database: 'strapi',
  },
})

