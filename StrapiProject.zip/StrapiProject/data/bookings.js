module.exports=[
    {
      "flight": "df7578a088680341",
      "seat_count": "5",
      "email": "a1@abc.com"
    },
    {
        "flight": "df7578a088680341",
        "seat_count": "3",
        "email": "a2@abc.com"
    },
    {
        "flight": "eb366cb823a56e0e",
        "seat_count": "2",
        "email": "a3@abc.com"
    },
    {
        "flight": "df9a6ac85fb071c4",
        "seat_count": "6",
        "email": "a4@abc.com"
    },
    {
        "flight": "5e4a4d7ed2adb8df",
        "seat_count": "2",
        "email": "a5@abc.com"
    }
];  