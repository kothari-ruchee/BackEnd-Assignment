module.exports=[
    {
      "code":"df7578a088680341",  
      "departure_at": "2021-10-01T18:25:00Z",
      "seat_count": "10",
      "launching_site": "a3742e26-ac9d-4dee-9b21-af447d1a2eee",
      "landing_site": "199d9776-3e20-41d1-8d74-5e247bdc2a52"
    },
    {
        "code":"4645ddf09fcb1395", 
        "departure_at": "2021-10-02T07:00:00Z",
        "seat_count": "5",
        "launching_site": "da9c2dee-3b38-4d21-b911-083599c05dad",
        "landing_site": "3d1d7388-5760-4658-aa3d-b90d88cc457d"
      },
      {
        "code":"eb366cb823a56e0e",  
        "departure_at": "2021-10-25T08:25:00Z",
        "seat_count": "4",
        "launching_site": "c34b6ac2-ba04-47fb-8421-37d565cdaae7",
        "landing_site": "06ab59b4-4ccb-49a0-b714-c1a70542b41b"
      },
      {
        "code":"df9a6ac85fb071c4", 
        "departure_at": "2021-10-01T07:45:43Z",
        "seat_count": "8",
        "launching_site": "ee1e3351-fd1e-462c-9fc8-441bd9d4eb31",
        "landing_site": "a721033e-41a4-413d-9e65-854c33635b61"
      },
      {
        "code":"a567d63f3d39909d",   
        "departure_at": "2021-11-15T09:15:43Z",
        "seat_count": "5",
        "launching_site": "7d15aeab-4566-4653-bbba-7206db064483",
        "landing_site": "fbf304e2-af2e-4f59-8a30-cdb72c33ac2c"
      },
      {
        "code":"9bb386feb6582509", 
        "departure_at": "2020-12-12T10:25:00",
        "seat_count": "6",
        "launching_site": "98f1fc21-1876-4c2b-b3d4-f670b6fd5545",
        "landing_site": "614de1e5-f9c2-438b-bc29-a4b83a7de729"
      },
      {
        "code":"5e4a4d7ed2adb8df", 
        "departure_at": "2021-12-11T14:10:15",
        "seat_count": "7",
        "launching_site": "42033815-b112-4afc-95bf-3c6bf108b818",
        "landing_site": "1ff41f9e-ac60-4761-909c-b599c64b04a0"
      }
  ];  