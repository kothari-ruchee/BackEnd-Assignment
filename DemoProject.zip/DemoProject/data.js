const knex=require('./db')


 async function getAllPlanets() {
    return response = await knex('planets').select('*') 
    
 }

  async function  getPlanetByID(planetID) 
  {
        const response = await knex('planets').select('*').where('id',planetID) 
        return response[0]
  }

  

  async function getPageDetails(args) {
      var page =args.page
      var pageSize=args.pageSize
      var email=args.email

       if(pageSize==null)
          pageSize=10
       else if(pageSize>100)
          pageSize=100
       else if(pageSize<0)
            pageSize=1
 
        if(page<0||page==null)
             page=1

      return {
         page: page,
         pageSize: pageSize,
         email:email
        }

  }

  
 async function getPageInfo(tablename,page,pageSize) {
    const response = await knex(tablename).count('id as total')
    return {
        total: response[0].total,
        page: page,
        pageSize: pageSize
               
    }
  }

  async function getListOfSpaceCenters(page,pageSize){
    var offset=(page-1)*pageSize
    return await knex('space_centers').orderBy('id').limit(pageSize).offset(offset)
        
  }   

 

  async function getListOfFlights(page,pageSize){
    var offset=(page-1)*pageSize
     return await knex('flights').orderBy('id').limit(pageSize).offset(offset)
      
} 

  async function getBookings(page,pageSize,email){
    var offset=(page-1)*pageSize
     return await knex('bookings').where('email',email).orderBy('id').limit(pageSize).offset(offset)
      
}  

async function getBookingByID(id){
    const response= await knex('bookings').where('id',id)
    return response[0]
}

  async function getSpaceCentersByPlanetCode(planet,args){
    if(args.limit==null)
        args.limit=5    
    if(args.limit>10)
        args.limit=10      
    const result =  await knex('space_centers').where('planet_code',planet.id).limit(args.limit)
    return result
  }

  async function getSpaceCenterByID(id,uid){
      var response =null
      if(id==null&&uid!=null)
         response = await knex('space_centers').where('uid',uid)
      else if(uid==null&&id!=null)
         response = await knex('space_centers').where('id',id)
      if(response==null)
        return null
       else
        return response[0] 

  }

  async function getFlightByID(id){
      const response= await knex('flights').where('id',id)
      return response[0]
  }

  async function getAvailableSeatCount(flight){
      const result= await knex('bookings').sum('seat_count as booked').where('flight_id',flight.id)
      const availableSeats= flight.seat_count - result[0].booked
      return availableSeats

  }
   
  async function scheduleFlight(args) {
    return await knex('flights').returning('*').insert({
      code: genHexString(16),
      departure_at:args.departureAt,
      launching_site: args.launchSiteId,
      landing_site: args.landingSiteId,
      seat_count:args.seatCount
    })
      
  }

  async function bookFlight(args){ 

      const flight=await getFlightByID(args.flightId)
      const availabileSeatCount=await getAvailableSeatCount(flight)
      if(availabileSeatCount<args.seatCount){
          console.log('Not enough seats available')
          return null
      }
      else{
      return knex('bookings').returning('*').insert({
        seat_count:args.seatCount,
        flight_id:args.flightId,    
        email:args.email      
    })
    }
  }


  function genHexString(len) {
    let output = '';
    for (let i = 0; i < len; ++i) {
        output += (Math.floor(Math.random() * 16)).toString(16);
    }
    return output;
}

  module.exports=({getAllPlanets,
    getPageDetails,
    getPlanetByID,
    getListOfSpaceCenters,
    getPageInfo,
    getSpaceCentersByPlanetCode,
    getSpaceCenterByID,
    getFlightByID,
    getAvailableSeatCount,
    getBookings,
    getListOfFlights,
    getBookingByID,
    scheduleFlight,
    bookFlight})
    