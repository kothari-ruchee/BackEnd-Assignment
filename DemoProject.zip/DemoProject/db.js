const knex = require('knex')

module.exports = knex({
  client: 'postgres',
  connection: {
    host: 'db',
    user: 'test',
    password: 'password',
    database: 'test',
  },
})

