const knex=require('../db')

;(async () => {
    try {
    await  knex.schema.dropTableIfExists('bookings')
                    .dropTableIfExists('flights')
                    .dropTableIfExists('space_centers')
                    .dropTableIfExists('planets')
    await knex.schema
        .createTable('planets', function(table) {
            table.increments('id').primary()
            table.string('name').notNullable()
            table.string('code').notNullable().unique() 
        })
        .createTable('space_centers', function(table) {
            table.increments('id').primary()
            table.string('uid').unique()
            table.string('name')
            table.text('description')
            table.float('latitude')
            table.float('longitude')            
            table.integer('planet_code').unsigned().references('planets.id');
        }) 
        .createTable('flights', function(table) {
            table.increments('id').primary()
            table.string('code',16).unique()
            table.datetime('departure_at', { useTz: true, precision: 6 }).defaultTo(knex.fn.now(6))
            table.integer('launching_site').unsigned().references('space_centers.id')
            table.integer('landing_site').unsigned().references('space_centers.id')
            table.integer("seat_count").unsigned()
        })
        .createTable('bookings', function(table) {
            table.increments('id').primary()
            table.integer("seat_count").unsigned()
            table.string('email')
            table.integer('flight_id').unsigned().references('flights.id');
        })
        console.log('Created all tables!')
        process.exit(0)
}
catch(err){
    console.log(err)
    process.exit(1)
}
})()



